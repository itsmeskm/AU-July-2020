module Hibernate {
	requires java.sql;
}