import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Simple Operation';
  emp=[
    {fname:"Subhash",lname:"mandal",age:"23",e_id:"37",city:"Dhanbad"},
    {fname:"Mayank",lname:"Gupta",age:"22",e_id:"34",city:"Ranchi"}
  ];
  model:any={};
  model1:any={};
  addUser(){
    this.emp.push(this.model);
    this.model={};
  }
  delUser(i){
    this.emp.splice(i,1);
  }
  val;
  editUser(k){
    this.model1.fname = this.emp[k].fname;
    this.model1.lname = this.emp[k].lname;
    this.model1.age = this.emp[k].age;
    this.model1.e_id = this.emp[k].e_id;
    this.model1.city = this.emp[k].city;
    console.log(k)
    this.val = k;
  }
  update(){
    let k= this.val;
    for(let i=0; i<this.emp.length;i++){
      if(i==k){
        this.emp[i]= this.model1;
        this.model1 = {};
      }
    }
  }
sort_fname = () =>{
  this.emp.sort((a,b) => a.fname.localeCompare(b.fname));
  return ;
}
sort_lname = () =>{
 this.emp.sort((a,b) => a.lname.localeCompare(b.lname));
 return ;
}
sort_age = () =>{
  this.emp.sort((a,b) => a.lname.localeCompare(b.lname));
return ;
}
sort_empid = () =>{
  this.emp.sort((a,b) => a.lname.localeCompare(b.lname));
return ;
}
sort_city = () =>{
this.emp.sort((a,b) => a.city.localeCompare(b.city));
return ;
}
}
