const express = require('express');
const logger = require('morgan');
const socket = require('socket.io');
const fs = require('fs');
const readline = require("readline");

const buttonPressesLogFile = './files/logfile.txt';

var change;
//App
const app = express();

app.use(logger('dev'));

app.set('view engine','ejs');

app.get('/main',function(req,res) {
    res.statusCode = 200;
    res.setHeader('Content-type', 'text/html');
    res.render('main');
});

const server = app.listen(4000,function() {console.log('Server is running');});

var io = socket(server);

io.on('connection', (socket) => {
    console.log('Socket is created');
    console.log(socket.id);
    const readInterface = readline.createInterface({
        input : fs.createReadStream('./files/logfile.txt'),
        output : process.stdout,
        console : false
    });

    readInterface.on('line', function(line){
        console.log(line);
        io.sockets.emit('logfileupdate',line);
    });

    console.log(`Watching for file changes on ${buttonPressesLogFile}`);

    fs.watchFile(buttonPressesLogFile, (curr, prev) => {
        if(!change) {
            console.log(`${buttonPressesLogFile} file Changed`);

            const readInterface = readline.createInterface({
                input : fs.createReadStream('./files/logfile.txt'),
                output : process.stdout,
                console : false
            });

            var i=0;
            readInterface.on('line', function (line) {
                i++;
            }).on('close', function() {
                i=i-10;
                var j=0;
                const readInterface2 = readline.createInterface({
                    input : fs.createReadStream('./files/logfile.txt'),
                    output : process.stdout,
                    console : false
                });
                readInterface2.on('line', function(line){
                    console.log(line);
                    j++;
                    if(j>=i)
                    io.sockets.emit('logfileupdate',line);
                });
    
                
            })
            change = setTimeout(function() {change = null}, 5000);
            
        }
    });




});