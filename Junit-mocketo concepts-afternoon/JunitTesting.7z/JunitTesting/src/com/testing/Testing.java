package com.testing;

public class Testing {
		public int add(int x,int y) {
			return x+y;
		}
		public int countS(String str) {
			int count=0;
			for(int i=0;i<str.length();i++)
				if(str.charAt(i)=='s' || str.charAt(i)=='S')
					count++;
			return count;
		}
}
