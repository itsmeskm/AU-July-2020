package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestingTest {

	@Test
	void testAdd() {
		Testing add=new Testing();
		int res=add.add(7,6);
		assertEquals(13,res);
	}

	@Test
	void testCountS() {
		Testing check=new Testing();
		int res=check.countS("itsmeskm");
		assertEquals(2,res);
	}

}
