module JunitTesting {
	requires org.junit.jupiter.api;
	requires junit;
	requires mockito.all;
}