package moc.testing;

public interface Interface {
	   public int square(int x);
	   public int power(int x,int y);
	   public double multiply(double x, double y);
	   public double divide(double x, double y);
	}
