package moc.testing;

import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ApplicationTester {
	
   @InjectMocks 
   Application application = new Application();

   
   @Mock
   Interface calfunc;

  
   public void testSquare(){
      when(calfunc.square(10)).thenReturn(100);
		
      
      Assert.assertEquals(application.square(10),100);
   }
}