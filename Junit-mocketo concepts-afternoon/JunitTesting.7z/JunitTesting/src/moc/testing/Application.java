package moc.testing;

public class Application {
	private Interface func;

	   public void setfunc(Interface func){
	      this.func = func;
	   }
	   
	   public int square(int x){
	      return func.square(x);
	   }
	   
	   public int power(int x, int y){
	      return func.power(x,y);
	   }
	   
	   public double multiply(double x, double y){
	      return func.multiply(x, y);
	   }
	   
	   public double divide(double x, double y){
	      return func.divide(x, y);
	   }
}
