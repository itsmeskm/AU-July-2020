package com.ism.au.model;

public interface Shape {
	public double area();
}
