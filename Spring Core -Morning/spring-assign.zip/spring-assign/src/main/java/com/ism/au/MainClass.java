package com.ism.au;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ism.au.model.Circle;
import com.ism.au.model.Triangle;

public class MainClass {

	public static void main(String[] args) {
		System.out.println("Hello World");
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("file.xml");
		Triangle tri = context.getBean(Triangle.class);
	      System.out.println(tri.getType());
	    Circle circle = context.getBean(Circle.class);
	    System.out.println(circle.getStr());
	    System.out.println(tri.area());
	    System.out.println(circle.area());
	}

}
