package com.ism.au.model;

public class Circle implements Shape{
	private Point center;
	private int str;
	public Point getCenter() {
		return center;
	}
	public void setCenter(Point center) {
		this.center = center;
	}
	public int getStr() {
		return str;
	}
	public void setStr(int str) {
		this.str = str;
	}
	public double area() {
		return (3.14*str*str);
	}
}
