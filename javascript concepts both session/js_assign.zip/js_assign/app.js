let arr=[4,8,12,24,57];
let a=[34,56,67,23,48];
arr=arr.concat(a);
arr.forEach((val)=>console.log(val));

arr=arr.filter((val)=>val>10);
//console.log(arr);

arr.push(34);
arr.push(56);arr.push(76);
//console.log(arr.length);

console.log(arr.indexOf(56));
console.log(arr.indexOf(99));
//console.log(arr.length);

arr=arr.map((val) => val+5);
//console.log(arr);

console.log(arr.pop());
//console.log(arr);

arr=arr.reverse();
//console.log(arr);

//console.log(arr.shift());
//console.log(arr);

//console.log(arr.slice(1,4));

const mod=(val) =>val%31===0;
console.log(arr.some(mod));

arr=arr.sort();
//console.log(arr);

console.log(arr.toString());
