function myfunc(e){
    let regex=document.getElementById('regex').value;
    console.log(regex);
    const re=/^[hdn]ot.*[hdn]o+t$/;
    if(re.test(regex))
     alert("String matches");
    else alert("String does not matches");
    e.preventDefault();
}

function myarr(e){
    let a=document.getElementsByName('arr');
    let b=[];
    for(let i=0;i<a.length;i++)
    {
     b.push(a[i].value);
    }
    b=b.sort(function(x, y){return x - y});
     b=b.filter((val)=>val>10);
    for(let i=0;i<b.length;i++)
    {
        b[i]=(+b[i])+1;
    }
     let str="";
    for(let i=0;i<b.length;i++)
    {
        if(i<4)
        {
         str+=b[i];
         str+=" ";
        }
    }
    alert(`Resulted array is ${str}`);
    e.preventDefault();
}
