import { Component,EventEmitter } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor() {}
  title = 'Parent Component';
  dis=true;
  arr= [
    {id:1,title : 'Angular'},
    {id:2,title : 'React'},
    {id:3,title : 'Vue'}
  ]

}
