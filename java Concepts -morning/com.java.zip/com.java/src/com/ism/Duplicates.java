package com.ism;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Duplicates {
	public static void check(ArrayList<String> para)
    {
       
        Map<String, Integer> mp = new HashMap<String, Integer>();

        for (String i : para) {
            Integer j = mp.get(i);
            mp.put(i, (j == null) ? 1 : j + 1);
        }

       
        for (Map.Entry<String,Integer> entry : mp.entrySet())  
            System.out.println("char = " + entry.getKey() + 
                             ", times = " + entry.getValue());
        }
    
	public static void main(String[] args) {
		
        ArrayList<String> str = new ArrayList<String>();
        str.add("i");
        str.add("t");
        str.add("s");
        str.add("m");
        str.add("e");
        str.add("s");
        str.add("k");
        str.add("m");
        str.add("a");
        str.add("b");
        str.add("w");
       
        check(str);
	}
}
