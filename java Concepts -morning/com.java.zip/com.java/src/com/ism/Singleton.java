package com.ism;
 
class singletonclass{
	
	private static singletonclass obj=null;
	
	public String s;
	
	private singletonclass()
	{
		s="This is singleton class";
	}
	
	
	public static singletonclass getInstance()
	{
		if(obj==null)
			obj=new singletonclass();
		return obj;
	}
}


//main class 
public class Singleton {
	public static void main(String [] args)
	{
		
		singletonclass instance1=singletonclass.getInstance();
		singletonclass instance2=singletonclass.getInstance();
		singletonclass instance3=singletonclass.getInstance();
		
		
		instance1.s=(instance1.s).toUpperCase();
		
		System.out.println("String from instance1 is " + instance1.s); 
        System.out.println("String from instance2 is " + instance2.s); 
        System.out.println("String from instance3 is " + instance3.s); 
        System.out.println("\n"); 
        
       
        instance3.s = (instance3.s).toLowerCase(); 
        
        System.out.println("String from instance1 is " + instance1.s); 
        System.out.println("String from instance2 is " + instance2.s); 
        System.out.println("String from instance3 is " + instance3.s);
	}

}