
//We have to add two dependencies
const express = require('express')
const app = express()
const port = 3000
const bodyParser = require('body-parser'); 
app.use(bodyParser.json()); 
var arr=[{
	id:1,
  fname:"Subhash",
  lname:"Mandal",
  city:"Suriya",
  age:23
},
{
  id:2,
  fname:"Mayank",
  lname:"Gupta",
  city:"Dhanbad",
  age:23
},
{
	id:3,
  fname:"Rajan",
  lname:"Jaiswal",
  city:"Ranchi",
  age:22
},
{
	id:4,
  fname:"Sushil",
  lname:"Rajak",
  city:"Giridih",
  age:26
}]

app.get("/arr",(req,res)=>res.json(arr))

app.get("/arr/:x",(req,res)=>{res.json(arr.filter((y)=>{return y.id==req.params.x}))})

app.post('/arr_add', function (req, res) {
     var data=JSON.parse(req.body["query"]);
    arr.push(data);
   return res.json(arr);
});

app.post('/arr_update',(req,res)=>{
    var data=JSON.parse(req.body["query"]);
	for(var i=0;i<arr.length;i++)
	{
		if(arr[i].id==data.id)
		{
			arr[i].title=data.title;
		}
		return res.json(arr)
	}
	return res.json(arr)
});

app.delete('/arr_delete/:x', function(req, res) {
    for(var i=0;i<arr.length;i++)
    {
        if(arr[i].id == req.params.x)
        {
            arr.splice(i,1);
			return res.json(arr)
        }
    }
    return res.json("No Element with the given id found")
})
//ADD 
app.listen(port, () => console.log(`Example app listening at http://localhost:${port}`))